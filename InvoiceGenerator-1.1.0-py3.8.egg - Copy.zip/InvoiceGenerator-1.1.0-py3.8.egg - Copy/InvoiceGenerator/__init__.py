VERSION = (1, 1, 0)

__version__ = VERSION
__versionstr__ = '.'.join(map(str, VERSION))
